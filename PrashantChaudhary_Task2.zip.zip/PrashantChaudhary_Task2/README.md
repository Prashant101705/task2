# Laundry Wallah
This is my HTML Task 2 project

## Files
-index.html
-README.md

Created by:
Prashant Chaudhary
